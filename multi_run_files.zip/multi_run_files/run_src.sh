#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=02:00:00
#SBATCH -o output/logs/%x_%j.out
#SBATCH -e output/logs/%x_%j.err

echo "=== Job Info ==="
echo "Node: $(hostname)"
echo "Job ID: $SLURM_JOB_ID"
echo "Start: $(date)"
echo "================="

module load cuda/11.8.0
source ~/miniconda3/etc/profile.d/conda.sh
conda activate test

echo ">>> Running Command: $@"
$@
echo ">>> Finished at: $(date)"
