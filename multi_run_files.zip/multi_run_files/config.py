# config.py
from dataclasses import dataclass

@dataclass
class Config:
    test_size: float = 0.2
    random_state: int = 42
    n_estimators: int = 100
    max_depth: int | None = None
    n_jobs: int = -1  # 모든 CPU 코어 사용