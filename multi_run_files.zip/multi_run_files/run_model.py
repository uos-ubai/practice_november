# run_model.py
import os
import sys
import datetime
import pandas as pd

from config import Config
from utils import evaluate, print_result
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.datasets import fetch_california_housing

def train_and_evaluate(cfg: Config):
    """RandomForest 모델 학습 및 평가"""
    print(f"\n [n={cfg.n_estimators}, d={cfg.max_depth}] 실험 시작")

    # 1. 데이터 로딩
    housing = fetch_california_housing()
    X, y = housing.data, housing.target

    # 2. 데이터 분할
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=cfg.test_size, random_state=cfg.random_state
    )

    # 3. 모델 학습
    model = RandomForestRegressor(
        n_estimators=cfg.n_estimators,
        max_depth=cfg.max_depth,
        random_state=cfg.random_state,
        n_jobs=cfg.n_jobs
    )
    model.fit(X_train, y_train)
    print(f"[n={cfg.n_estimators}, d={cfg.max_depth}] 모델 학습 완료")

    # 4. 예측 및 평가
    y_pred = model.predict(X_test)
    metrics = evaluate(y_test, y_pred)
    print_result(metrics)

    # 5. 결과 저장 (타임스탬프 포함)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    result_path = f"output/results/result_{cfg.n_estimators}_{cfg.max_depth}_{timestamp}.csv"

    df_result = pd.DataFrame([{
        "n_estimators": cfg.n_estimators,
        "max_depth": cfg.max_depth,
        **metrics
    }])
    df_result.to_csv(result_path, index=False)
    print(f"[n={cfg.n_estimators}, d={cfg.max_depth}] 결과 저장 완료 → {result_path}")


if __name__ == "__main__":
    # 하이퍼파라미터 CLI 인자 수신
    n_estimators = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    max_depth = None if len(sys.argv) < 3 or sys.argv[2] == "None" else int(sys.argv[2])

    # 설정 객체 생성 및 실행
    cfg = Config(n_estimators=n_estimators, max_depth=max_depth)
    train_and_evaluate(cfg)
