# utils.py
import numpy as np
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

def evaluate(y_true, y_pred):
    """R2, MAE, RMSE 계산"""
    r2 = r2_score(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    return {"r2": r2, "mae": mae, "rmse": rmse}

def print_result(metrics):
    print("\n 모델 평가 결과")
    for k, v in metrics.items():
        print(f"{k.upper():<5}: {v:.4f}")