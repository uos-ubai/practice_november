#!/bin/bash

# 실험 파라미터 조합
N_ESTIMATORS=(50 100)
MAX_DEPTHS=(5 10)

DEFAULT_NAME=multi_run_test

# GPU 파티션/노드 설정
DEVICES=(
    "--partition=gpu1 --nodelist=n010 --gres=gpu:rtx3090:1"
    "--partition=gpu6 --nodelist=n027 --gres=gpu:a10:1"
    "--partition=gpu2 --nodelist=n055 --gres=gpu:a10:1"
    "--partition=gpu4 --nodelist=n092 --gres=gpu:a6000:1"
)

RUN_SRC=./run_src.sh
ENV=/home1/rldnjs16/miniconda3/envs/test/bin/python
EXEC_FILE=/home1/rldnjs16/practice/multi_run_files/run_model.py

mkdir -p output output/logs output/results

index=0
for n in "${N_ESTIMATORS[@]}"; do
  for d in "${MAX_DEPTHS[@]}"; do
    # 노드 순환 배정
    device_index=$((index % ${#DEVICES[@]}))
    device_opts=${DEVICES[$device_index]}

    JOB_NAME=${DEFAULT_NAME}${n}_${d}
    CMD="$ENV $EXEC_FILE $n $d"

    echo "Submitting Job $JOB_NAME → ${device_opts}"
    sbatch --job-name=$JOB_NAME ${device_opts} $RUN_SRC "$CMD"

    ((index++))
    sleep 1
  done
done
